
package penjualanbarang;

/**
 *
 * @author ALIVIO H.Y
 */
public class barangclass {
    private String kode, nama;
    private float harga, bayar, qty;

    public String getKode() {
        return kode;
    }

    public void setKode(String kode) {
        this.kode = kode;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public float getHarga() {
        return harga;
    }

    public void setHarga(float harga) {
        this.harga = harga;
    }

    public float getBayar() {
        return bayar;
    }

    public void setBayar(float bayar) {
        this.bayar = bayar;
    }

    public float getQty() {
        return qty;
    }

    public void setQty(float qty) {
        this.qty = qty;
    }
}
