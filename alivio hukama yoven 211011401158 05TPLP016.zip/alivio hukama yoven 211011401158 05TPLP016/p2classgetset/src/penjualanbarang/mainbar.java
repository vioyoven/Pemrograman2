/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package penjualanbarang;

import java.util.Scanner;

public class mainbar {
    public static void main(String[] args){
        Scanner ketik = new Scanner(System.in);
        barangclass[] bar = new barangclass[0];  //dri class bisa jadi array class
        int ch = 0, x, jumlah;
        
        do{
        System.out.println("PILIH MENU");
        System.out.println("===========================================");
        System.out.println("1.input pembelian");
        System.out.println("2.tampil total bayar");
        System.out.println("3.keluar program");
        System.out.println("===========================================");
        System.out.print("pilih? ");
        ch = ketik.nextInt();
        System.out.print("");
        switch (ch)
        {
            case 1:
            System.out.print("jumlah tipe barang   ");
            jumlah = ketik.nextInt();
            bar = new  barangclass[jumlah];    
            for (x=0;x<jumlah;x++)
            {
            bar[x]=new barangclass();
            System.out.println("data :"+ (x+1));
            System.out.print("kode   :"); bar[x].setKode(ketik.next());
            System.out.print("nama  :"); bar[x].setNama(ketik.next());
            System.out.print("harga   :"); bar[x].setHarga(ketik.nextFloat());
            System.out.print("qtybarang   :"); bar[x].setQty(ketik.nextFloat());
            }           
            break;
            
            case 2:
            x=0;
            while (x<bar.length)
            {
            System.out.println("data :"+ (x+1));
            System.out.print("kode   :"+ bar[x].getKode());
            System.out.print("nama  :"+ bar[x].getNama());
            System.out.print("harga   :"+ bar[x].getHarga());
            System.out.print("qtybarang   :"+ bar[x].getQty());
                
            }
                
            break;
            
            case 3:
            System.out.println("selesai");    
            break;
        }
        
            
        }while (ch!=3);
    }
    
    
}
