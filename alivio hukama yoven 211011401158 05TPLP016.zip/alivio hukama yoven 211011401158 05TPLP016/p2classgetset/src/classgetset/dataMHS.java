
package classgetset;

import java.util.Scanner;
import classgetset.MHS;


public class dataMHS {
      static double nilakhir;
      static String grade;
    
    public static void main(String[] args){
        Scanner input= new Scanner(System.in);
        MHS[] mhs = new MHS[0];
        int jml, x, pil;
        float nuts, nuas;
        
        do{
        System.out.println("PILIH MENU");
        System.out.println("===========================================");
        System.out.println("1.input data");
        System.out.println("2.tampil data");
        System.out.println("3.keluar program");
        System.out.println("===========================================");
        
        System.out.print("pilih? ");
        pil = input.nextInt();
        System.out.print("");
        switch(pil)
        {
            case 1:
            System.out.print("jumlah data   ");
            jml = input.nextInt();
            mhs = new MHS[jml];
            for (x=0;x<jml;x++)
            {
            mhs[x]=new MHS();
            System.out.println("data :"+ (x+1));
            System.out.print("nim   :"); mhs[x].setNim(input.next());
            System.out.print("nama  :"); mhs[x].setNama(input.next());
            System.out.print("uts   :"); nuts=input.nextFloat();
            System.out.print("uas   :"); nuas=input.nextFloat();
            mhs[x].setUts(nuts);
            mhs[x].setUas(nuas);
            }
            break;
            
            case 2:
            System.out.println("tampil data"); 
            x=0;
            while (x<mhs.length)
            {
            System.out.println("data    :"+ x+1);
            System.out.println("nim     :"+ mhs[x].getNim());
            System.out.println("nama    :"+ mhs[x].getNama());
            System.out.println("uts     :"+ mhs[x].getUts());
            System.out.println("uas     :"+ mhs[x].getUas());   
            System.out.println("nilakhir:"+ mhs[x].getNilAkhir());   
            System.out.println("grade   :"+ mhs[x].getGrade());  
            x++;
            }
            break;
            
            case 3:
            System.out.println("selesai");
            break;
            
        }
        }while (pil!=3);
        
    }
            
    
}
